import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cliente-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './cliente-form.component.html',
  styleUrls: ['./cliente-form.component.css']
})
export class ClienteFormComponent {
  @Output() clienteAdicionado = new EventEmitter<any>();

  clienteForm = this.fb.group({
    nome: ['', Validators.required],
    cpf: ['', [Validators.required, this.validarCPF]],
    dataNascimento: ['', Validators.required],
  });

  constructor(private fb: FormBuilder) {}

  onSubmit() {
    if (this.clienteForm.valid) {
      this.clienteAdicionado.emit(this.clienteForm.value);
      this.clienteForm.reset();
    }
  }

  validarCPF(control: AbstractControl): ValidationErrors | null {
    const rawValue = control.value;
    const cpf = typeof rawValue === 'string' ? rawValue.replace(/[^\d]+/g, '') : '';

    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) {
      return { cpfInvalido: true };
    }

    const calc = (factor: number) => (
      cpf.split('')
         .slice(0, factor - 1)
         .reduce((sum, digit, index) => sum + parseInt(digit, 10) * (factor - index), 0)
    );

    const result = (calc(10) * 10 % 11) % 10 === parseInt(cpf[9], 10) &&
                   (calc(11) * 10 % 11) % 10 === parseInt(cpf[10], 10);

    return result ? null : { cpfInvalido: true };
  }
}
